# v6.3.0-alpha1

- Add dedicated Joomla 6 compiler templates and generation settings.
- Update generated Joomla 6 database queries to use native query creation and query-level limits.
- Replace deprecated configuration and session calls in generated Joomla 6 extensions with native application access.
- Correct current-user injection and permission-state updates in generated Joomla 6 models.
- Use native injected database access in generated Joomla 6 tables.
- Use native cache services in generated Joomla 6 controllers and import handlers.
- Improve generated Joomla 6 exception handling while preserving form data, edit redirects and API responses.
- Move generated Joomla 6 component and module scripts and styles into their extension media directories.
- Migrate generated Joomla 6 asset loading to the Web Asset Manager with ordered dependencies and duplicate prevention.
- Update generated field scripts, charts, Footable, DKIM controls and loading overlays for native Joomla 6 asset handling.
- Restore footer JavaScript execution after page markup across views, fields and modules.
- Consolidate Joomla 6 Site View and Custom Admin View scripts into one ordered list, placing prerequisite scripts before view and model scripts.
- Initialize asset dependencies before library loading and respect the configured jQuery framework setting.
- Allow compiler build hooks to supply additional script paths and dependencies for individual Joomla 6 views.
- Move supported script-only PHP Document blocks, including Marked loading, into the ordered Joomla 6 script list.
- Reuse the existing Web Asset Manager for generated Joomla 6 administrator list scripts.
- Update generated Joomla 6 plugin providers to use configuration-only constructors and remove unused dispatcher imports.
- Add native Joomla 6 plugin event subscriptions and migration diagnostics for incompatible custom handlers.
- Update bundled privacy handler generation to use native Joomla 6 events.
- Update Joomla 6 module and plugin installers to native interfaces and return component installer instances while preserving custom lifecycle hooks.
- Correct Joomla 6 installation checks and enforce PHP 8.3 requirements in generated component installers.
- Update generated Joomla 6 toolbars to use native Save as Copy and Save and New button methods.
- Fix Joomla 6 plugin event registration to restore JCB compiler hooks.
- Preserve inherited constructors in compiler Power classes added for the Joomla 6 migration.
- Standardize indentation, line endings and source comments in generated code, including API PATCH and script registration, while preserving authored code.
- Preserve plugin provider namespace placeholders during JCB self-compilation so generated Joomla 4, 5 and 6 plugins use the correct namespaces.
- Return HTTP 404 from generated Joomla 6 API PATCH handlers when the target record cannot be loaded.
- Include extension, translated and untranslated filter states in Language Translations cache keys to keep cached records and totals separate.
- Fix Joomla 7.0 deprecation notices in the Component Builder helper and generated helper methods.
- Replace deprecated global configuration access with the active Joomla application's configuration in JCB services and upload handling.
- Replace deprecated GUID casts and cURL and MIME cleanup calls for PHP 8.5 compatibility.
- Preserve generated HTML tags and image attributes when parsing Markdown links and linked images.
- Fix legacy FOF encryption service initialization by removing unused dependency lookups.
- Declare core.api in generated components so authorized users can read Custom Admin Views through the API without core.manage on Joomla 6+.

# v6.2.1

- Fix Note and Spacer fields failing to save because hidden database settings were incorrectly required.
- Fix conditional field visibility and required-state updates after selector changes and AJAX refreshes.
- Fix chained conditions and numeric comparisons producing inconsistent browser and server validation.
- Fix generated JavaScript errors caused by special characters and leading-zero numbers in condition values.
- Fix conditional validation incorrectly making optional or disabled fields required again.
- Fix Markdown rendering of images, linked images and bracketed alternative text.
- Fix JCB Search pagination skipping or repeating records and potentially failing to finish.
- Fix legacy FOF encryption service initialization by removing unused dependency lookups.
- Fix generated frontend form navigation when custom view names are used. #1118
- Fix missing or misplaced Joomla Power imports, including Uri, in generated PHP classes. #1123
- Fix sales-server uploads over FTP and SFTP, including credential handling, authentication checks and remote paths. #1283
- Fix language-translation filtering for exact language matches, legacy NULL records, extension selections and cached results. #1309
- Normalize compiler-created translation records to the same empty value used by manual saves. #1309
- Correct the NotAllowed import so denied Site View and Custom Admin View API requests return HTTP 403 instead of HTTP 500. #1326
- Fix empty Site View and Custom Admin View API lists returning HTTP 500 return HTTP 200. #1330
- Fix infinite loops in Save as Copy and Batch Copy when unique numeric fields conflict with existing records, and report a clear error. #1328

# v6.2.0

- Add a dedicated Extrusion view for importing existing Joomla components and PHP libraries into JCB.
- Unify component-folder and SQL-dump extrusion through a single engine.
- Add PHP class harvesting into JCB Powers, including automatic class matching and dependency linking.
- Add import pairing with Create, Update, and Skip controls, dry runs, and per-record change previews.
- Improve SQL schema reconstruction to preserve column types, defaults, keys, indexes, and table configuration.
- Improve field imports to preserve XML settings, options, GUID relationships, and storage formats without double-encoding subform data.
- Reuse shared field definitions across views and preserve existing customizations during repeated imports.
- Detect unchanged records and avoid unnecessary writes during repeated Extrusion runs.
- Restore language strings and compiler placeholders in imported code, field XML, view markup, and SQL.
- Improve Site View and Custom Admin View discovery, template recovery, and Dynamic Get relationships.
- Fix Power namespace reconstruction to correctly preserve custom aliases and apply NamespacePrefix and ComponentNamespace placeholders.
- Fix duplicate Compile button submissions that could start concurrent builds and cause intermittent folder creation or deletion errors. #1318
- Add Repair Existing Power Namespaces with automatic matching and namespace-only updates that preserve class code, GUIDs, and settings.
- Improve Power discovery performance with component-scoped matching, dependency indexes, and reusable parsing.
- Protect Extrusion imports against ambiguous matches, conflicting compiler paths, and stale change previews.
- Improve Extrusion error reporting and recovery after interrupted import requests.
- Improve the Extrusion interface with folder pickers, grouped filtering, bulk selection, responsive layouts, and a dedicated dashboard icon.
- Fix Extrusion self-compilation by preserving runtime marker literals and align import authorization with native view-access permissions.
- Replace execution of imported SQL with static parsing and validate source paths without executing imported PHP.
- Complete JSON:API generation for API-enabled Admin Views, including CRUD operations, relationships, filtering, pagination, and field-level permissions.
- Include generated API files in component manifests so they are installed with compiled components.
- Add API_ROUTES and API_ROUTES_METHOD placeholders for linked webservices plugins, supporting routes by record ID, GUID, and unique fields.
- Add read-only API resources for supported Site Views and Custom Admin Views using their existing Dynamic Gets.
- Fix API record creation when IDs and GUIDs are omitted, generate record keys on the server, and preserve existing GUIDs during updates.
- Fix API item and list model selection, including resource names with irregular plural forms.
- Fix API read permissions to support read-only users and return native JSON:API access-denied responses instead of administrator redirects.
- Fix cross-site scripting risks in generated views through corrected text sanitization, Joomla-native HTML escaping, and field escape settings.
- Fix edit-own permission bypasses by checking stored record ownership and applying field permissions to the record being saved.
- Strengthen file upload and deletion permissions with ownership and component permission checks.
- Fix subform updates that could overwrite or reassign records belonging to another parent.
- Block unsafe URL schemes in Markdown links and images.
- Use cryptographically secure randomness for generated passwords and upload names, and sanitize uploaded filenames.
- Fix generated IIS library access configuration and add missing index.html files to compiled folders.
- Complete extraction of generated-code logic from the legacy Fields, Interpretation, and Infusion helpers into dedicated compiler services.
- Consolidate shared compiler logic across Joomla versions while retaining version-specific generation where required.
- Refactor the Power parser to use PHP's native lexer for reliable handling of modern syntax, multiline declarations, and complex types.
- Fix JCB Search to prevent matching records from being skipped when processing successive batches.
- Fix compilation of database-aware Joomla 4 modules caused by a missing utility class import.
- Fix CLI repository resolution to report unresolved repository GUIDs without triggering a fatal error.
- Fix PHP warnings when the compiler's placeholder report contains no results.
- Fix toolbar generation when descriptions are missing or null.
- Preserve original source line endings when compiler processing leaves the content unchanged.

# v6.1.6

- Add Health Check buttons to the JCB Compiler and Component list view to verify system PHP configuration.
- Add the Toolbar Custom Buttons subform to the Global Subform settings for improved usability and presentation.
- Fix the Field edit view to ensure full compliance with Joomla 6 standards and updated UI/UX conventions.
- Begin migration from UIkit to Bootstrap 5 to align JCB with Joomla 6+ standards.
- Complete Bootstrap 5 refactor of all primary views and core UI.
- Continue phased removal of UIkit with full transition planned for upcoming releases.
- Fix deprecated JText usage in Admin Custom Tabs area for Joomla 5+ compatibility. #1302
- Fix snippet loading for Joomla 6, improving reliability and removing legacy UIkit dependencies during migration.
- Introduced strict version-aware compilation to ensure libraries are only included when explicitly defined for Joomla 6.
- Disabled automatic UIkit injection for Joomla 6, preventing auto-loading across custom admin views, site views, templates, and layouts.
- Migrate Search view for J6 to use Bootstrap and Joomla-native HTML and JavaScript.
- Remove all manually linked Bootstrap v4 assets from the component.
- Improve subform ordering fields for clearer display and better readability.
- Refactor the JavaScript waiting spinner to use solid, native JavaScript with improved page-loading handling.

# v6.1.5

- Fix variable name mismatch for organization in the Network Resolve class. #1291
- Fix issue where Admin Field relations using custom code did not automatically include multiple fields as expected. #1293
- Fix issue where Admin Field relations did not correctly apply concatenation/glue options. #1294
- Refactor Compiler functions to improve maintainability and align with modern PHP coding best practices.
- Refactor the JCB Dashboard, introducing a modernized layout, improved usability, and full responsiveness across desktop, tablet, and mobile devices.
- Fix deprecated warnings triggered in the JCB CLI.
- Fix resolve PHP syntax errors and PHP 8.4 deprecations across codebase.
- Fix four fatal parse/compile errors.
- Fix implicit nullable parameter deprecations.

# v6.1.4

- Fix the linked [new] button to use the correct init_default params.
- Fix the Components list view to better display long website urls.
- Fix language text area css. #1264
- Refactor the JS selText method.
- Add fix for empty currentFullPath in the Structuresingle class.
- Fix the buildSelectPart method to not access an empty select value in the Queries class.
- Fix that ensure that we always load and int into loadUserById.
- Fix the subform permission behaviour to use removeField.
- Add version 6 to the version 5 update server, for easier upgrade path.
- Fixed linked admin views with New and New & Close buttons to correctly initialize fields using global unique IDs and default conventions.
- Resolved missing language strings when linked admin views are also configured as site edit views.
- Corrected misconfiguration of the isModal property for site-linked views to default to false since modals are not yet supported on the site area.
- Enhanced security in edit views by moving access validation into the model, ensuring protection even when Joomla bypasses the controller layer.
- Added user access verification logic in the model to prevent unauthorized direct item loading.
- Refactored the view class to introduce a class constructor that initializes key dependencies more reliably.
- Began aligning the view class structure with Joomla 6's updated MVC architecture for future compatibility.
- Improved initialization handling in the view to reduce dependency errors during rendering.
- Fixed a bug caused by missing option settings in the model configuration.
- Updated and refined the site view class for greater consistency with backend view logic.
- Continued progressive improvements across view classes to ensure compatibility with Joomla's evolving MVC patterns.
- Fix permission issue in the list view. #1266
- Refactor the list view buttons.
- Refactor the getActions helper method.
- Rename Custom Buttons tab to Toolbar for clearer grouping of toolbar functions. #1268
- Add options for overriding default toolbars in all Admin, Site, and Custom Admin Views. #1268
- Refactor toolbar into version specific classes to resolve getToolbar errors. #1267
- Add method to unify getDatabase handling across Joomla versions and prevent undefined method calls. #1270
- Fix php8.3 deprecation warnings in compiler templates. #1265
- Refactor and enhance the JCB Email Helper class for a more robust and maintainable design.
- Fix an issue where the Email Helper send() function was executed twice.
- Fix a issue where layouts added to the PHP Ajax Model were not loaded during compilation.
- Add new functionality to the toolbar override system, enabling the inclusion of custom buttons via placeholders.
- Fix the Compiler success message to display both build seconds and project weeks.
- Add Development Valuation Model to calculate JCB component pricing.
- Add functionality to push JCB packages to Self hosted Git system that uses a self signed SSL.
- Add functionality that will include Validation Rules linked to fields in JCB packages. #1273
- Refactor and Improve Router Helper Class to new standard Site Router practice.
- Refactor and Improve JCB Search engine for better searching of JCB areas.
- Fix bug in the search editor in JCB Search Engine.
- Fix issue where Custom Gets linked to a Site view did not ship correctly with JCB packages. #1272
- Fix issue where the Icon linked to a Custom Admin Menu did not ship with JCB packages. #1271
- Fix and Improve Normalize Class to better handle different files Linked to JCB packages. #1274
- Remove batch feature from JCB compiler Templates due to lack of use and outdated code.
- Refactor Utilities/Response classes for Joomla 6+ compatibility and improved version-agnostic behavior.
- Refactor the File Upload Manager to achieve improved maintainability, greater customization flexibility, and easier extensibility.
- Refactor the Item Importer to improve data management, structural clarity, and long-term maintainability of the import process.
- Add a Pull button to all main JCB entities, allowing a complete reset of a selected entity together with all entities linked to it, from a selected remote repository.
- Add functionality to the compiler to automatically pull missing entities from a remote repository when they are referenced by a component but not present locally in JCB.
- Refactor the Packaging Engine into separate set and get classes to improve separation of concerns, readability, and overall maintainability.
- Refactor and restructure the demo console item import plugin to improve usability, maintainability, and reusability across other areas of JCB.
- Refactor the Compiler to remove deprecated code paths and legacy classes that are no longer maintained.
- Add new Compiler Classes to modernise ancient tech previously embedded in the compiler and replace it with a clean, modern architecture.
- Add a dedicated CLI plugin to the JCB core, enabling direct interaction with JCB through the Joomla CLI console.
- Add structured CLI commands and options to Init, Reset, Push, and Pull JCB entities via the Joomla CLI.
- Add full support for compiling Components directly via the CLI, enabling automated and headless build workflows.
- Add functionality to place Super Power classes into the component src folder for both Admin and Site areas, using the correct namespaced structure.
- Add functionality to the CLI compiler to directly install compiled components and apply compiler options used during compilation.
- Add functionality to the compiler to automatically pull a missing component from a remote repository when a compilation is triggered and the component is not locally available.
- Add functionality to add and replace classes in module and plugin src folders that are linked to a component, when using correct namespace resolution.
- Add a Documentation tab to the Joomla Component Builder dashboard.
- Fix an issue with the JCB version notice on Joomla 5.
- Fix an issue where components without a component image failed to compile successfully. #1282
- Add functionality for importing translated language strings directly into the Language Translations area of JCB.
- Fix issue where the Language Translations export button was not displayed due to recent toolbar changes.
- Fix a bug that caused language filters to malfunction because of a broken field configuration. #1278
- Fix issue where components without a layout added to the Component failed to compile correctly. #1132

# v6.1.3

- Stability update addressing a post-release field issue. #1262
- Fix a security vulnerability in custom code redirect URL validation.
- Add an alert to the Compiler view when no Components exist. #1263

# v6.1.2

- Add Joomla 6 build option
- Fix the template and layout linker for packages.
- Add native module builder for Joomla 4/5
- Refactor dynamic get methods into dedicated classes
- Move Joomla DB handling into compiler injector flow
- Fix auto-check(in) method for Joomla 4/5 compatibility
- Migrates view HTML classes to use getModel() directly instead of the deprecated magic get() calls to model methods.
- Refactores event handling (contentPrepare, titlePrepare, contentBeforeDisplay, contentAfterDisplay) to use Joomla 5's native event dispatcher via the model's new getDispatcher() method.
- Updates table classes to properly support NULL values, both in the store() method and in table variable definitions. #1245
- Extractes the setAutoCheckIn() and setCheckInCall() logic into a dedicated CheckInNow class for cleaner design.
- Replace all direct $app->input property calls with the recommended $app->getInput() method across the entire codebase.
- Add Joomla 6 build option :)
- Fix Custom Rule Validation Bug
- Unpublish Joomla 6 Backward Compatibility Plugin
- Refactors the Compiler Model by dropping deprecated calls and adopting Joomla 5+ conventions
- Refactors Compiler Controller to remove deprecated usage and follow Joomla 5+ best practices
- Adds check to ensure expert mode subforms in the Demo Component remain set and unchanged when user lacks edit permissions
- Improves validation handling of Fields by ensuring field validation rules are properly registered
- Replace StringHelper with the correct Super Power key so it loads in the Compiler Controller
- Add functionality to add component changelog into the package if configured.
- Refactor PHP classes for building HTML view files in admin and site views to align with Joomla 5+ standards.
- Fix issues in the site view HtmlView caused by the refactor, including missing class calls and outdated function references.
- Fix issue where the DatabaseSchemaCheckAll pulled all Component Builder tables into DB on install. #1253
- Fix issue in the Dynamic Get when the value key is 0 it wouldn't add the 'WHERE' statement to the generated code. #1254
- Change radio buttons with a empty option to save Datatype CHAR instead of TINYINT as other radio buttons. #1252
- Add extra xml details to Modules built with JCB that adds advance options to the module. #1248
- Remove setDocumentTitle method from the admin view since it is not being used by Joomla. #1255
- Refactor compiler Move file update to classes.
- Refactor compiler Move plugin and module fields and rules files mover to classes.
- Fix issue where custom powers was not added to PowerloaderHelper. #1256
- Fix normalization issue when compiling on Windows systems. #1219
- Fix installer issue on Joomla 6 where components containing multiple plugins failed during installation.
- Completely refactors the Compiler Dashboard to align with Joomla 5+ architecture and Bootstrap 5 standards.
- Add a default VARCHAR(36) length to easily create fields intended to store GUID values.
- Update the file uploader in the Demo Component for more dynamic file display and naming.
- Update the SQL file dump generator to handle large SQL dumps in batches, ensuring safe and reliable database imports.
- Update example hints in the field expert mode options.

# v5.2.1

- Fix Note and Spacer fields failing to save because hidden database settings were incorrectly required.
- Fix conditional field visibility and required-state updates after selector changes and AJAX refreshes.
- Fix chained conditions and numeric comparisons producing inconsistent browser and server validation.
- Fix generated JavaScript errors caused by special characters and leading-zero numbers in condition values.
- Fix conditional validation incorrectly making optional or disabled fields required again.
- Fix Markdown rendering of images, linked images and bracketed alternative text.
- Fix JCB Search pagination skipping or repeating records and potentially failing to finish.
- Fix legacy FOF encryption service initialization by removing unused dependency lookups.
- Fix generated frontend form navigation when custom view names are used. #1118
- Fix missing or misplaced Joomla Power imports, including Uri, in generated PHP classes. #1123
- Fix sales-server uploads over FTP and SFTP, including credential handling, authentication checks and remote paths. #1283
- Fix language-translation filtering for exact language matches, legacy NULL records, extension selections and cached results. #1309
- Normalize compiler-created translation records to the same empty value used by manual saves. #1309
- Correct the NotAllowed import so denied Site View and Custom Admin View API requests return HTTP 403 instead of HTTP 500. #1326
- Fix empty Site View and Custom Admin View API lists returning HTTP 500 return HTTP 200. #1330
- Fix infinite loops in Save as Copy and Batch Copy when unique numeric fields conflict with existing records, and report a clear error. #1328

# v4.2.1

- Fix Note and Spacer fields failing to save because hidden database settings were incorrectly required.
- Fix conditional field visibility and required-state updates after selector changes and AJAX refreshes.
- Fix chained conditions and numeric comparisons producing inconsistent browser and server validation.
- Fix generated JavaScript errors caused by special characters and leading-zero numbers in condition values.
- Fix conditional validation incorrectly making optional or disabled fields required again.
- Fix Markdown rendering of images, linked images and bracketed alternative text.
- Fix JCB Search pagination skipping or repeating records and potentially failing to finish.
- Fix legacy FOF encryption service initialization by removing unused dependency lookups.
- Fix generated frontend form navigation when custom view names are used. #1118
- Fix missing or misplaced Joomla Power imports, including Uri, in generated PHP classes. #1123
- Fix sales-server uploads over FTP and SFTP, including credential handling, authentication checks and remote paths. #1283
- Fix language-translation filtering for exact language matches, legacy NULL records, extension selections and cached results. #1309
- Normalize compiler-created translation records to the same empty value used by manual saves. #1309
- Correct the NotAllowed import so denied Site View and Custom Admin View API requests return HTTP 403 instead of HTTP 500. #1326
- Fix empty Site View and Custom Admin View API lists returning HTTP 500 return HTTP 200. #1330
- Fix infinite loops in Save as Copy and Batch Copy when unique numeric fields conflict with existing records, and report a clear error. #1328

# v3.2.5

- Add [AllowDynamicProperties] in the base view class for J5
- Move the _prepareDocument  above the display call in the base view class
- Remove all backward compatibility issues, so JCB will not need the [Backward Compatibility] plugin to run.
- Added new import powers for custom import of spreadsheets.
- Move the setDocument and _prepareDocument above the display in the site view and custom admin view.
- Update the trashhelper layout to work in Joomla 5.
- Add AllowDynamicProperties (Joomla 4+5) to view class to allow Custom Dynamic Get methods to work without issues.
- Fix Save failed issue in dynamicGet. #1148
- Move all [TEXT, EDITOR, TEXTAREA] fields from [NOT NULL] to [NULL]
- Add the DateHelper class and improve the date methods.
- Add simple SessionHelper class.
- Add first classes for the new import engine.
- Improve the [VDM Registry] to be Joomla Registry Compatible
- Move all registries to the [VDM Registry] class
- Fix Checked Out to be null and not 0. (#1194)
- Fix created_by, modified_by, checked_out fields in the compiler of the SQL. (#1194)
- Update all core date fields in table class. (#1188)
- Update created_by, modified_by, checked_out fields in table class.
- Implementation of the decentralized Super-Power CORE repository network. (#1190)
- Fix the noticeboard to display Llewellyn's Joomla Social feed